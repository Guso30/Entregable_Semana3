defmodule Delete do
  @moduledoc """
  This module provides functions for delete Employees from a JSON file.

  ## Special Symbols
  - `defmodule`: Defines a new module
  - `@moduledoc`: Provides documentation for the module
  """

  alias Empresa.Employee

  @doc """
  Deletes an Employee from the JSON file based on their ID.

  ## Parameters
  - `id`: Integer, the ID of the employee to delete
  - `filename`: String, the name of the JSON file to update (optional, default: "employees.json")

  ## Returns
  - `:ok` if the delete operation is successful
  - `{:error, :not_found}` if the employee is not found

  ## Special Symbols
  - `@doc`: Provides documentation for the function
  - `@spec`: Specifies the function's type specification
  - `def`: Defines a public function
  - `\\\\`: Default argument separator
  - `case`: Pattern matches on the result of an expression
  - `|>`: The pipe operator

  ## Examples
      iex> Delete.delete_employee(1)
      :ok

      iex> Delete.delete_employee(999)
      {:error, :not_found}
  """
  @spec delete_employee(integer(), String.t()) :: {:ok, Employee.t()} | {:error, :not_found}
  def delete_employee(id, filename \\ "employees.json") do
    employees = read_employees(filename)
    updated_employees = Enum.reject(employees, &(&1.id == id))

    case length(updated_employees) < length(employees) do
      true ->
        json_data = Jason.encode!(updated_employees, pretty: true)
        File.write(filename, json_data)
        :ok
      false ->
        {:error, :not_found}
    end
  end

  @doc """
  Reads existing employees from the JSON file.

  ## Parameters
  - `filename`: String, the name of the JSON file to read from

  ## Returns
  - List of Employee structs

  ## Special Symbols
  - `@doc`: Provides documentation for the function
  - `@spec`: Specifies the function's type specification
  - `defp`: Defines a private function
  - `case`: Pattern matches on the result of an expression

  ## Examples
      iex> Writer.read_employees("employees.json")
      [%Empresa.Employee{...}, ...]
  """
  @spec read_employees(String.t()) :: [Employee.t()]
  defp read_employees(filename) do
    case File.read(filename) do
      {:ok, contents} ->
        Jason.decode!(contents, keys: :atoms)
        |> Enum.map(&struct(Employee, &1))
      {:error, :enoent} -> []
    end
  end
end
