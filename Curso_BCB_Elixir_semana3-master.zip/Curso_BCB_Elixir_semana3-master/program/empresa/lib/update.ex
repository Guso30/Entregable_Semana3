defmodule Update do
  @moduledoc """
  This module provides functions for update employees in a JSON file.

  ## Functions
    - `update_employee/2`: Updates an employee's details in the JSON file based on their ID.
  """

  alias Empresa.Employee

  @doc """
  Updates an existing Employee in the JSON file based on their ID.

  ## Parameters
  - `employee`: An Empresa.Employee struct with updated details
  - `filename`: String, the name of the JSON file to update (optional, default: "employees.json")

  ## Returns
  - `:ok` if the update operation is successful
  - `{:error, :not_found}` if the employee is not found

  ## Examples
      iex> employee = Empresa.Employee.new("Gustavo", "Engineer", email: "gustavo@mail.com", phone: "31244488990")
      iex> Update.update_employee(employee)
      :ok

      iex> Update.update_employee(%Empresa.Employee{id: 999, name: "Unknown"})
      {:error, :not_found}
  """
  @spec update_employee(Employee.t(), String.t()) :: :ok | {:error, :not_found}
  def update_employee(%Employee{id: id} = updated_employee, filename \\ "employees.json") do
    employees = read_employees(filename)

    updated_employees =
      Enum.map(employees, fn
        %Employee{id: ^id} -> updated_employee
        employee -> employee
      end)

    case Enum.find(employees, &(&1.id == id)) do
      nil ->
        {:error, :not_found}

      _ ->
        json_data = Jason.encode!(updated_employees, pretty: true)
        File.write(filename, json_data)
        :ok
    end
  end

  @doc """
  Reads existing employees from the JSON file.

  ## Parameters
  - `filename`: String, the name of the JSON file to read from

  ## Returns
  - List of Employee structs

  ## Special Symbols
  - `@doc`: Provides documentation for the function
  - `@spec`: Specifies the function's type specification
  - `defp`: Defines a private function
  - `case`: Pattern matches on the result of an expression

  ## Examples
      iex> Writer.read_employees("employees.json")
      [%Empresa.Employee{...}, ...]
  """
  @spec read_employees(String.t()) :: [Employee.t()]
  defp read_employees(filename) do
    case File.read(filename) do
      {:ok, contents} ->
        Jason.decode!(contents, keys: :atoms)
        |> Enum.map(&struct(Employee, &1))

      {:error, :enoent} ->
        []
    end
  end
end
